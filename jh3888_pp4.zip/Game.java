//* This Class simulates a Video Poker Game
//* author: Ji Ho Hyun
//* uni: jh3888
//* 4/3/18
  
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Game {
	
	private Player p;
	private Deck cards;    
    private ArrayList<Card> hand;
	// you'll probably need some more here
	
	
	public Game(String[] testHand)
    {
		// This constructor is to help test your code
		// use the contents of testHand to
		// make a hand for the player
		// use the following encoding for cards
		// c = clubs
		// d = diamonds
		// h = hearts
		// s = spades
		// 1-13 correspond to ace - king
		// example: s1 = ace of spades
		// example: testhand = {s1, s13, s12, s11, s10} = royal flush
		
        
        p = new Player();
        cards=new Deck();
        
        for(int i=0; i<5; i++)
        {
            String temp=testHand[i]; 
            String s=temp.substring(0, 1);
            String r=temp.substring(1, temp.length());
            //System.out.println(s);
            //System.out.println(r);
                
            
                
            int suit=0;
            
            if (s.equals("c"))
            {
                suit=1;
            }
            if (s.equals("d"))
            {
                suit=2;
            }
            if (s.equals("h"))
            {
                suit=3;
            }
            if (s.equals("s"))
            {
                suit=4;
            }
            int rank=Integer.parseInt(r);
            Card c = new Card(suit, rank);
            p.addCard(c);
            
        }
        
	}
	
	public Game()
    {
		// This no-argument constructor is to actually play a normal game
		
        p=new Player();
        
        cards=new Deck();
       
	}
	
	public void play()
    {
		// this method should play the game
		int quit=1;
        do{
        System.out.println("Hello, welcome to Video Poker "+ 
                           "Insert your bet please! (1-5 tokens)");
        p.bets();
        cards.shuffle();        
        fillHand();    
        p.sortHand();
        
        //Displaying the cards, runs a for loop for each time a card is removed
        System.out.println("Your hand is " + "\n");
        System.out.println(p.revealHand());
        System.out.println("How many cards would you like to remove?");
        Scanner scan=new Scanner(System.in);
        int l = scan.nextInt();
        
        for(int i=0; i<l; i++)
        {
            System.out.println("Which of the cards "+ 
                               "would you like to remove? (1, 2, 3 etc.)");
            Scanner scan2=new Scanner(System.in);
            int m = scan2.nextInt();
            //Card c = indexToCard(m);
            p.removeCard(m-1);
            redraw();
            p.sortHand();
            System.out.println("Your hand is now: ");
            System.out.println(p.revealHand());
        }
                   
            p.sortHand();        
            System.out.println("Your hand has: "+checkHand(p.getHand())+"");
            
            p.getOdds(checkHand(p.getHand()));
            
                       
            p.winnings(p.getOdds(checkHand(p.getHand())));
        
            double reward=p.getBankroll();
            double cash=p.money(p.getOdds(checkHand(p.getHand())));
            System.out.println("You won: $"+cash+"!");
            System.out.println("Current Total Earnings: $"+reward+"!");
            
            (p.getHand()).clear();
            System.out.println("Would you like to play again? "+ 
                               "If yes, press 1. If no, press 0.");
            quit=scan.nextInt();
            
        }while(quit!=0);
        
	}
    
    public void fillHand()
    {
        for(int i=0;i<5;i++)
        {
            
            Card c=cards.deal(i);        
            p.addCard(c);   
        }
        cards.dealReset();
    }
    
    
    // Created a redraw class that replenishes discarded Cards
    public void redraw()
    {
        
            int j=0;
            cards.shuffle();
            Card c=cards.deal(j); 
            p.addCard(c);    
        
    }
    
       
	public String checkHand(ArrayList<Card> hand)
    {
		// this method should take an ArrayList of cards
		// as input and then determine what evaluates to and
		// return that as a String
		
        // Essentially just a really long 
        // if statement that returns the hand's hand
		
        String score="";
        if (isHandRoyalFlush(hand))
        {
            return score= "Royal Flush";
        }
        if (isHandStraightFlush(hand))
        {
            return score= "Straight Flush";
        }
        
        if (isHand4Kind(hand))
        {
            return score= "Four of a Kind";
        }
        
        if (isHandFullHouse(hand))
        {
            return score= "Full House";
        }
        
        if (isHandFlush(hand))
        {
            return score= "Flush";
        }
        
        if (isHandStraight(hand))
        {
            return score= "Straight";
        }
        
        if (isHand3Kind(hand))
        {
            return score= "Three of a Kind";
        }
        
        if (isHand2Pair(hand))
        {
            return score= "Two Pairs";
        }
        
        if (isHand1Pair(hand))
        {
            return score= "One Pair";
        }
      
        if (isHand0Pair(hand))
        {
            return score= "No Pairs";
        }
        return score;
            		
	}
    
    // Various booleans that test for a specific hand:
    // This boolean tests for a Royal Flush hand
    public boolean isHandRoyalFlush(ArrayList<Card> hand)
    {
                   
        for (int i=1; i<3; i++)
        {
            if ((isHandFlush(hand)&&(isHandStraight(hand)))&&
                ((hand.get(0)).getRank()==10))
               
            {
                return true;
            }
        
        
        }                
                return false;
       
    }
    // this boolean tests for a straight flush
    public boolean isHandStraightFlush(ArrayList<Card> hand)
    {
        
        if ((isHandStraight(hand))&&(isHandFlush(hand)))
        {
            return true;
        }
        
            return false;

    }
    // this boolean tests for a 4 of a Kind hard
    public boolean isHand4Kind(ArrayList<Card> hand)
    {
                
        for(int i=0;i<2;i++)
            {
                if ((hand.get(i).getRank()==(hand.get(i+3)).getRank()))
                {
                    return true;
                    
                }
                         
            }
        return false;
        
    }
    
    // this boolean tests for a full house
    public boolean isHandFullHouse(ArrayList<Card> hand)
    {
        
        
        int i=0;
        
         if ((((hand.get(i)).getRank()==(hand.get(i+1)).getRank())&&
             (((hand.get(i+1)).getRank())==(hand.get(i+2)).getRank()))&&
            (hand.get(i+3)==hand.get(i+4))||
            ((hand.get(i)).getRank()==(hand.get(i+1)).getRank())&&
            ((hand.get(i+2)).getRank()==(hand.get(i+3)).getRank())&&
            ((hand.get(i+3).getRank()==(hand.get(i+4)).getRank())))
            {
            
            return true;
            }   
        
        
        
        return false;
    }
    // this boolean tests for a flush hand
	public boolean isHandFlush(ArrayList<Card> hand)
    {
        int count = 0;
        for (int i=1; i<5; i++)
        {
            if((hand.get(i-1)).getSuit()==(hand.get(i)).getSuit())
            {
                          
                count++;
         
            }
        }
        if (count==4)
        {
            return true;
        }    
            
            return false;
            
    }
    // Tests for straight hand
	public boolean isHandStraight(ArrayList<Card> hand)
    {
        
         if (hand.get(0).getRank()==1 && 
            hand.get(1).getRank()==10 &&
            hand.get(2).getRank()==11 &&
            hand.get(3).getRank()==12 &&
            hand.get(4).getRank()==13)       
        {                
            return true;
        
        }
        for(int i=0; i<hand.size()-1; i++)
        {
            if(hand.get(i).getRank()==hand.get(i+1).getRank()-1)
            {
                return true;
            }
            
        }      

        return false;
              
    }
            
         
    // tests for three of a kind hand
    public boolean isHand3Kind(ArrayList<Card> hand)
    {
        
        for(int i=0; i<3; i++)
        {
            if ((hand.get(i)).getRank()==(hand.get(i+2)).getRank())
            {
                
                return true;
            }
        
        
                 
        }       
                return false;
        
    }
    // tests for a hand with two pairs
    public boolean isHand2Pair(ArrayList<Card> hand)
    {
      
        
        for(int i=0; i<4; i++)
        {
            if (((hand.get(i)).getRank()==(hand.get(i+1)).getRank()))
            {
                ArrayList<Card> newHand=new ArrayList<Card>(hand);
                newHand.remove(i+1);
                newHand.remove(i);
                return (true && isHand1Pair(newHand));
            }           
   
        }         
            return false;        
    }
    
    // tests for a single pair
    public boolean isHand1Pair(ArrayList<Card> hand)
    {
        if (hand.size()<2)
        {
            return false;
        }
        for(int i=0; i<hand.size()-1; i++)
        {
            if (((hand.get(i)).getRank()==(hand.get(i+1)).getRank()))
            {
                
                return true;
            }           
    
        }
        return false;
    }
    
    // the only remaining case is when there are no card combinations
    public boolean isHand0Pair(ArrayList<Card> hand)
    {
        
        if ((isHand1Pair(hand)==false)&&
            (isHandStraight(hand)==false)&&
            (isHandFlush(hand)==false))
        {
            
            return true;
        }
        
            return false;
            
    }
                
	
}


