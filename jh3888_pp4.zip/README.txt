﻿README.txt
Name: Ji Ho Hyun
UNI: jh3888
Assignment: Programming Project 4




===============================================================================
<(Card.java)>
===============================================================================




I think creating the Card class was the easiest part of this project; the only issue was implementing Comparable<> so that Hand could later be sorted. However, this was covered extensively in class so it wasn’t bad at all.






===============================================================================
<(Deck.java)>
===============================================================================




My approach to this class was to see how it was similar to CD collection, because  I understood how that worked. deal() is a really important method for the rest of the project. I also created a deck reset method that sets the top back to 0.




===============================================================================
<(Player.java)>
===============================================================================




Player was hard because I couldn’t wrap my head around the idea that the hand always stays within it. I put most of the methods involving hand functions into this class, such as adding Cards to the empty hand ArrayList<>. I created several methods outside of the template one, such as revealHand() which prints out the hand in a nicer manner, or getHand, which returned the hand to outside the class. I also put a Sort class that sorts the hand based on rank.




===============================================================================
<(Game.java)>
===============================================================================


Game was really difficult, and I think that my code still has some minor issues. But the basic structure involves sending information between Deck, Game, and Player. For example, I would call a card from Deck using deck.deal(), and send it to the Player’s hand using the Game. The most complex part was CheckHand(). Essentially, I set up a number of booleans that were then called in a method that went down the line from Royal Flush all the way to No Pair, and the method stopped at the first Boolean that was true to return the score of the Card.