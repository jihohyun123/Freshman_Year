//* This Class simulates a Poker Card
//* author: Ji Ho Hyun
//* uni: jh3888
//* 4/3/18

public class Card implements Comparable<Card>{
	
	private int suit; // use integers 1-4 to encode the suit
	private int rank; // use integers 1-13 to encode the rank
	
	public Card(int s, int r)
    {
        suit = s;
        rank = r;
        
		//make a card with suit s and value v
	}
	public int getSuit()
    {
        return suit;
    }
    public int getRank()
    {
        return rank;
    }
	public int compareTo(Card c)
    {
		// use this method to compare cards so they 
		// may be easily sorted
		int answer = 0;
        if (this.rank>c.rank)
        {
            answer = 1;
        }
        if (this.rank==c.rank)
        {
            if (this.suit<c.suit)
            {
                answer = -1;
            }
            if (this.suit>c.suit)
            {
                answer = 1;
            }
        }
        if (this.rank<c.rank)
        {
            answer=-1;
            
        }
        return answer;
            

	}
	
	public String toString()
    {
		// use this method to easily print a Card object
        
        String about;
        about = "{" + rank + " of " + suit + "}";
        return about;
        
	}
    
    public String intToSuit(int suit)
    {
        String type="";
        if (suit==1)
        {
            type = "clubs";
        }
        if (suit==2)
        {
            type = "diamonds";
        }
        if (suit==3)
        {
            type = "hearts";
        }
        if (suit==4)
        {
            type = "spades";
        }
        return type;
    }
    public String intToRank(int rank)
    {
        String face="";
       
        {
            if (rank==1)        
            {
                face="ace";        
            }
            else if (rank==11)
            {
                face="jack";
            }
            else if (rank==12)
            {
                face="queen";
            }
            else if (rank==13)
            {
                face="king";
            }
            else
            {
                face=Integer.toString(rank);
            }
        
        }
        return face;
    }
	// add some more methods here if needed

}
