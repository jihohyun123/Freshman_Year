//* This Class simulates a Poker Deck
//* author: Ji Ho Hyun
//* uni: jh3888
//* 4/3/18
  
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;

public class Deck 
{
	
	private Card[] cards;
    private ArrayList<Card> deck;
	private int top; // the index of the top of the deck

	// add more instance variables if needed
	
	public Deck()
    {
        // make a 52 card deck here
		deck = new ArrayList<Card>(); 
        createDeck();       
	
    }
    // allows access to deck from elsewhere
    
    
    // creates a new deck
    public void createDeck()
    {
                
        for (int i=1; i<=4; i++)
        {
            
            for (int j=1; j<=13; j++)
            {
                
                Card temp = new Card(i, j);
                
                deck.add(temp);
            }
            
        }
        
    }
	
    // shuffles a deck
	public void shuffle()
    {
		// shuffle the deck here
		for (int i=0; i<500; i++)
        {
        
            int shuffleIndex1=(int)(Math.random()*52);
        
            int shuffleIndex2=(int)(Math.random()*52);
            
            while ((int)(Math.random()*52) != (int)(Math.random()*52))
        
            {
            
                Card temp1 = deck.get(shuffleIndex1);
            
                Card temp2 = deck.get(shuffleIndex2);
                        
                deck.set(shuffleIndex1, temp2);
                        
                deck.set(shuffleIndex2, temp1);
            
        
            }
        }
    }
        
    public ArrayList returnDeck()
    {
        return deck;
    }
	public Card deal(int top)
    {
		// deal the top card in the deck
		int n=top;        
        Card topCard = deck.get(n);            
        top++;
        
        return topCard;
	}
    public void dealReset()
    {
        top = 0;
    }
	
	// add more methods here if needed

}

