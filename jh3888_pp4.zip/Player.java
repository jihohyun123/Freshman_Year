//* This Class simulates a Video Poker Player
//* author: Ji Ho Hyun
//* uni: jh3888
//* 4/3/18
  
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Player {
	
		
	private ArrayList<Card> hand; // the player's cards
	private double bankroll;
    private double bet;
    private Deck deck=new Deck();
    private ArrayList<Card> cards=deck.returnDeck();

	// you may choose to use more instance variables
		
	public Player()
    {		
	    // create a player here
	    hand=new ArrayList<Card>();
        bet=0;
        
	   	    
	}

	public void addCard(Card c)
    {
	    // add the card c to the player's hand
	    
        {
            
            hand.add(c);
        }
	        
	}
    
    public ArrayList<Card> getHand()
    {
        return hand;
    }
    
    
    public String revealHand()
    {
        String handGrid="";
        for (int i=0; i<5; i++)
        {
            Card c=hand.get(i);
            c.intToSuit(c.getSuit());
            c.intToRank(c.getRank());
            String description=("["+c.intToRank(c.getRank()) + " of " + c.intToSuit(c.getSuit())+"]"+"    ");
            handGrid=handGrid+description;    
        }
        
        
        return handGrid+"\n";
    
    }
    
    public void sortHand()
    {
        Collections.sort(hand);
    }

    //changed the method from calling a card to calling an int
    //which works better with my code
	public void removeCard(int n)
    {
	    // remove the card c from the player's hand
        hand.remove(n);  
    }
    
	
      
    public void bets()
        
    {
        // player makes a bet           
        
        Scanner scan=new Scanner(System.in);
        bet=scan.nextDouble();
        
    }
    public double getBets()
    {
        return bet;
    }
    public double getOdds(String score)
    {
        int odds=0;
        if (score.equals("Royal Flush"))
        {
            odds=250;
        }
        if (score.equals("Straight Flush"))
        {
            odds=50;
        }
        if (score.equals("Four of a Kind"))
        {
            odds=25;
        }
        if (score.equals("Full House"))
        {
            odds=6;
        }
        if (score.equals("Flush"))
        {
            odds=5;
        }
        if (score.equals("Straight"))
        {
            odds=4;
        }
        if (score.equals("Three of a Kind"))
        {
            odds=3;
        }
        if (score.equals("Two Pairs"))
        {
            odds=2;
        }
        if (score.equals("One Pair"))
        {
            odds=1;
        }
        if (score.equals("No Pairs"))
        {
            odds=0;
        }
        return odds;
        
    }
    public double money(double odds)
    {
        double cash=(getBets()*odds);
        return cash;
    }
        
    public void winnings(double odds)
        
    {
    
        //	adjust bankroll if player wins
        
        bankroll=bankroll+(getBets()*odds);
        
    }

    
    
    public double getBankroll()
    
    {
            // return current balance of bankroll
        
        return bankroll;
        
    }

        // you may wish to use more methods here
}


