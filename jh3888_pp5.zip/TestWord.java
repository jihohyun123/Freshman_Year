//*************************************
//
//  TestWord.java
//
//  Tests the WordLists class
//  Programming Project 5, COMS W1004
//
//
//  Your Name: Ji Ho Hyun
//  Your Uni: jh3888
//**************************************

import java.util.Scanner;
import java.io.*;
import java.util.*;

public class TestWord
{
    // inserted a throw exception for FileNotFoundException
    public static void main(String[] args) throws FileNotFoundException 
    {
        
        // a scanner that reads terminal inputs named bob
        Scanner bob = new Scanner(System.in);
        
        // asking for/receiving input
        System.out.println("Enter file name: ");
        String file = bob.nextLine();
        PrintWriter output = new PrintWriter("lengthN.txt");
        
        // creating a brand new WordLists!
        WordLists words = new WordLists(file);
        int length=0;
        
        /* lengthN(int n): returns an ArrayList of all words 
           length n in the dictionary file. */
        System.out.println("lengthN Test:");
        System.out.println("Enter a length");
        
        // this try-catch is for if the user accidentally inputs a wrong value
        try
        {
            length=bob.nextInt();
            bob.nextLine();
        }
        
        catch(InputMismatchException jill)
        {
            System.out.println("You've inputted an invalid value. Try again.");
            System.exit(1);
        }
        
        // creating a new file that can receive the output of the test:
        File newFile=new File("lengthN.txt");
        output = new PrintWriter(newFile);
        
        // printing on a new line using an enhanced for loop
        for(String word : words.lengthN(length))
        {
            output.println(word);       
        }
            output.close();
        
        
        /* startsWith(char firstLetter, int n): returns an ArrayList of words of
           length n beginning with the letter firstLetter */
        System.out.println("startsWith Test:");
        System.out.println("Enter a desired first letter");
        String desiredFirstLetter=bob.nextLine();
        // converting string to a char for the first letter
        char firstLetter=desiredFirstLetter.charAt(0);
        System.out.println("Enter a length");
        int length1=0;
        
        // just foolproofing the code
        try
        {
            length1=bob.nextInt();
            bob.nextLine();
            
        }
        catch(InputMismatchException jill)
        {
            System.out.println("You've inputted an invalid value. Try again.");
            System.exit(1);
        }
            
        // creating a file for the startsWith test
        File newFile2=new File("startsWith.txt");
        output = new PrintWriter("startsWith.txt");
        
        for(String word : words.startsWith(firstLetter, length1))
        {
            output.println(word); 
        }    
        output.close();
                
        
        /* containsLetter(char included, int n): returns an ArrayList of words
        of length n containing the letter included but not beginning with it. */      
        System.out.println("containsLetter Test:");
        System.out.println("Enter a desired letter");
        String wantedLetter=bob.nextLine();
        char letter=wantedLetter.charAt(0);
        System.out.println("Enter a length");
        int length2=0;
        
        // again testing for scenario where idiot user inputs wrong value
        try
        {
            length2=bob.nextInt();       
            bob.nextLine();            
        }
        
        catch(InputMismatchException jill)
        {
            System.out.println("You've inputted an invalid value. Try again.");
            System.exit(1);
        }
            
        // creating a new file for the containsLetter test
        File newFile3=new File("containsLetter.txt");       
        output = new PrintWriter("containsLetter.txt");
        for(String word : words.containsLetter(letter,length2))
        {
            output.println(word);
        }
        
        output.close();
        
        
        /* multiLetter(char included, int m): returns an ArrayList of words
        with at least m occurrences of the letter included. */        
        System.out.println("multiLetter Test:");
        System.out.println("Enter a desired letter");
        String desiredLetter=bob.nextLine();
        char desiredChar= desiredLetter.charAt(0);
        System.out.println("Enter the number of occurrences");
        int numberTimes=0;
        
        // in case the user inputs a wrong value    
        try
        {            
            numberTimes=bob.nextInt();        
            bob.nextLine();            
        }
        
        catch(InputMismatchException jill)
        {
            System.out.println("You've inputted an invalid value. Try again.");
            System.exit(1);
        }
        
        // creating a new file for the multiLetter test
        File newFile4=new File("multiLetter.txt");
        output = new PrintWriter("multiLetter.txt");
         
        for(String word : words.multiLetter(desiredChar, numberTimes))
        {
            output.println(word);
        }
        
        output.close();
        
        // closing the scanner
        bob.close();
                
    }
    
}
