//*************************************
//
//  WordLists.java
//
//  Class to aid with Scrabble
//  Programming Project 5, COMS W1004
//
//
//  Your Name: Ji Ho Hyun
//  Your Uni: jh3888
//**************************************

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;


public class WordLists 
{
    
    // instantiated some variables
    
    File input;
    String word;
    Scanner scan;
    
    public WordLists(String fileName)
    {

        // defined here, inside a try/catch(accounts for wrong file name)
        try
        {
        input = new File(fileName);        
        scan = new Scanner(input); 
        }
        catch(Exception e)
        {
            System.out.println("Wrong!");
            System.out.println("Please try again with a valid file name.");
            System.exit(1);
            
        }
    }

    // First test, checking for length alone
    public ArrayList<String> lengthN(int n)
    {
        // if the word matches, it is added to the array
        ArrayList a = new ArrayList<String>();
        int length=n;
        try
        {
        
            while(scan.hasNext())
            {
                word=scan.nextLine();
                
                if (word.length()==length)
                {
                    a.add(word);          
                }
            }          
            scan.close();       
        }
        
        catch(Exception e)
        {    
            System.out.println("oof 1");            
        }
        return a;
    }

    /* here the program runs through the dictionary file and looks
       for words that start with a certain letter. */
    public ArrayList<String> startsWith(char firstLetter, int n)
    {

        int length=n;
        
        // creating an ArrayList that the words can be added to:
        ArrayList b = new ArrayList<String>();
        
        try
        {
            scan = new Scanner(input); 
        
            while(scan.hasNext())
               
            {            
            word=scan.nextLine();
            
                char first=firstLetter;            
                
                // if the first character matches inputted letter
                if ((word.charAt(0)==first)&&(word.length()==length))
                {                
                    // the word is added to the array
                    b.add(word);            
                }
                   
            }
            scan.close();
        
        }
        catch(Exception e)
        {
            System.out.println("oof 2");
        }
        // returns the ArrayList
        return b;
    }

    // here the program looks for words that simply contain the specific letter
    public ArrayList<String> containsLetter(char included, int n)
    {    
        ArrayList c= new ArrayList<String>();
        
        try
        {
            scan = new Scanner(input); 
            
            // using useDelimiter() to get through each character
            scan.useDelimiter("");
            
            while(scan.hasNext())
            {            
                word=scan.nextLine();
                char lookingFor=included;
                int length=n;
                
                /* for loop with an if statement inside checks for words that
                   contain a specific letter NOT at the start of the word */
                
                for(int i=0; i<word.length(); i++)
                {
                    if ((word.charAt(0)!=included)&&
                        (word.charAt(i)==lookingFor)&&
                        (word.length()==length))
                    {
                        c.add(word);                    
                    }
                }
            }
            scan.close();
        }
        catch(Exception e)
        {
            System.out.println("oof 3");
        }
        return c;
    }
    
    // This method tests for multiple instances of a letter
    public ArrayList<String> multiLetter(char included, int m)
    {
        
        ArrayList d = new ArrayList<String>();
        
        try
        {
        scan = new Scanner(input); 
        while(scan.hasNext())
        {            
            word=scan.nextLine();
            char target=included;
            int number=m;
            int count=0;
            
            // added a counter to account for multiple instances of the letter
            for(int i=0; i<word.length(); i++)
            {
                if (word.charAt(i)==included)                
                {
                    count++;
                }
            }
            
            /* if the number of instances matches the desired count,
               the word is added to the index */
            if(count==number)
            {
                d.add(word);
            }
            
        }        
            scan.close();
        }
        
        catch(Exception e)
        {
            System.out.println("oof 4");
        }
        return d;
    }

} // end of class
