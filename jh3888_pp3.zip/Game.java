/*****************************************
 * This class runs a Nim game
 * 
 * @author Hyun
 * @uni jh3888
 
 ****************************************/ 

public class Game
{
    /* Some variables:
    marbles keeps track of all the marbles
    firstMove decides who goes first,
    and lastMove keeps track of who moved last*/
    
    private int marbles;
    private Human humanPlayer;
    private Computer computerPlayer;
    private int firstMove;
    

    
    public Game()
    {
        /* Here we are generating values for 
        marbles, firstMove, and computerMode using Math.random.
        
        The reason why in marbles 
        Math.random is multiplied by 91
        is because 10 to 100 includes 91 different numbers, 
        giving a range of 10.x-100.y, where x and y are decimal values
        which are irrelevant because of (int). */
        
        marbles=(int)((Math.random()*91)+10);
        
        firstMove=(int)(Math.random()*2);
        
        int computerMode = (int)(Math.random()*2);
        
        computerPlayer=new Computer(computerMode);//, marbles);
        
        humanPlayer=new Human();
        
        /* The game needs to print out values 
        for the player to be oriented 
        at the start of the game, so I had it print 
        marbles, computerMode, and firstMove. */
        
        System.out.println("The starting number of marbles is: "+marbles+"");
        System.out.println("The mode of the computer: "+computerMode+"" 
                           +" (1 for smart, 0 for stupid)");
        System.out.println("The starting player is: " 
                           +""+firstMove+" (1 for computer, 0 for human)");
        
    }
     
    public void play()
    {        
        /* Scenario one: firstMove is 0, so the human goes first, 
        alternating with the computer.
        humanPlayer.move() runs a human move, and 
        humanPlayer.getChoice() returns the choice.
        the choice is subtracted from the current pile of marbles, 
        and the result is printed.
        Also, lastMove starts at 0 and adds one 
        (so that at the end of the game we can determine who moved last)*/
        
        while ((marbles>0)&&(firstMove==0))
        {
                
            int lastMove=0;            
                
            humanPlayer.move();
                
            humanPlayer.getChoice();
                
            /* This statement takes care of the scenario 
            where the human player accidentally inputs an invalid choice.
            It ignores the invalid input and asks the user to input
            a new value. */
            
            if ((((humanPlayer.getChoice()>(marbles/2))||
                  (humanPlayer.getChoice()==0))&&(marbles!=1)))
                
            {
                    
                marbles=marbles;
                
                System.out.println("Invalid choice. Please try again");
                
                humanPlayer.move();
                
                humanPlayer.getChoice();
                
                marbles=marbles-(humanPlayer.getChoice());
                
                System.out.println("Remaining marbles: "+marbles+"");
                
                lastMove++;
                
            }
            // Otherwise the program runs like normal.    
            else
                
            {
                
                marbles=marbles-(humanPlayer.getChoice());
             
                System.out.println("Remaining marbles: "+marbles+"");
                
                lastMove++;
                
            }
                
        
        
            // Running a computer's turn
            if (marbles>0)
            {
                computerPlayer.move(marbles);
                
                computerPlayer.getChoice();
                
                marbles=marbles-(computerPlayer.getChoice());
                
                System.out.println("The computer has taken away "
                                   +""+computerPlayer.getChoice()+" marbles!");
                System.out.println("Remaining marbles: "+marbles+"");
                
                lastMove=lastMove-1;
            }
            
            /* In the case where there are no more marbles, the last player to
            have moved is the loser. The game ends with the return command. */
            
            if (marbles==0)
            {            
                if (lastMove==1)
                {
                    System.out.println("You lose!");
                    return;
                }
                else if(lastMove==0)
                {
                    System.out.println("You win!");
                    return;
                }
                        
       
            }
            
            
            
        }
               
        // This is scenario 2, where firstMove is 1 and the computer moves first
        while ((marbles>0)&&(firstMove==1))
        {
            int lastMove=1;
            
            computerPlayer.move(marbles);
            
            computerPlayer.getChoice();
            
            marbles=marbles-(computerPlayer.getChoice());
            
            System.out.println("The computer has taken away "
                               +""+computerPlayer.getChoice()+" marbles!");
            System.out.println("Remaining marbles: "+marbles+"");
            
            /* To keep lastMove consistent, I have it start at 1 
            and subtract 1 every time the computer moves. */
            
            lastMove=lastMove-1;
        
            if (marbles>0)
            {
                
                humanPlayer.move();
                
                humanPlayer.getChoice();
                
                if (((humanPlayer.getChoice()>(marbles/2))||
                     (humanPlayer.getChoice()==0))&&(marbles!=1))
                {
                    marbles=marbles;
                    System.out.println("Invalid choice. Please try again.");
                    
                    humanPlayer.move();
                    humanPlayer.getChoice();
                    
                    marbles=marbles-(humanPlayer.getChoice());
                    System.out.println("Remaining marbles: "+marbles+"");
                    
                    lastMove++;
                    
                }
                else
                {
                    marbles=marbles-(humanPlayer.getChoice());
                    System.out.println("Remaining marbles: "+marbles+"");
                    
                    lastMove++;
            
                    
                }
                
            }
            
            if (marbles==0)
            {
                if (lastMove==1)
                {
                    System.out.println("You lose!");
                    return;
                }
                else if (lastMove==0)
                {
                    System.out.println("You win!");
                    return;
                }
            
                
            
            }
      
                  
        
        }
            
            
    }
            
       
       
}