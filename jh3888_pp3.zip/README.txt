﻿README.txt
Name: Ji Ho Hyun        
UNI: jh3888
Assignment: PP3

===============================================================================
<CreditCard.java>
===============================================================================
I approached this problem by conceptualizing all the different tests that a credit card number would have to pass in order to be valid. I also went back and looked at all the things we can do with strings that are in Big Java, as well as the methods discussed in class. I didn’t use any methods outside of what was mentioned in the textbook/lecture, except for charAt(). I didn’t use any more classes than the given template. I did add a function to my class that removes the dash, in case credit card numbers are inputted with dashes.

===============================================================================
<Human.java>
===============================================================================

The Human class was pretty easy to come up because all I really needed was an input from the player regarding how many marbles to take away.

===============================================================================
<Computer.java>
===============================================================================
The Computer class was a little more complex than the Human class, because I had to account for the smart and stupid modes. In smart mode, the computer tries to take enough away from the pile that the remaining number is (2^n)-1, except in the case where the pile is already (2^n)-1 (where n is some integer). I had to use booleans to make sure that the Computer made the right decision. I was able to streamline the code a little by combining stupid mode with when the computer is unable to make a smart decision in smart mode with a single else statement (where it just makes a random legal move).







===============================================================================
<Game.java>
===============================================================================


The Game class was where I combined my Human and Computer classes to make a functioning Nim game. I drew inspiration from Cannon’s pig game in the sequencing of Human and Computer moves. I realized that I would have to generate a fair number of random values, so I used the Math.random() method a lot. In terms of the actual play() method, I created two scenarios: one where the human player goes first and one where the computer goes first. Within these two scenarios I also accounted for if a player accidentally inputs an invalid value. The players move(), getChoice(), and then a calculation is run that calculates how many marbles are left. A running tally called lastMove kept track of who had moved last so that a winner and a loser could be determined at the end of the game. I kept mostly within the template, and didn’t add any extra classes.

===============================================================================