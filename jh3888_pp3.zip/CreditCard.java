/*****************************************
 * A class that examines the validity of an
 * inputted credit card number
 * 
 * @author Hyun
 * @uni jh3888
 
 ****************************************/ 

public class CreditCard
{
    /* setting variables
    validity initially set as true */
    
    private boolean validity=true;
    private int errorCode=0;    
    private int sum = 0;
    private String number;    
    private int sum1;
    private int sum2;
        
    public CreditCard(String n)
    {
        // This is just to remove all the dashes
        number = n.replace("-","");
        
    }   
    
    /* The method where the number is checked,
    runs a number of tests. If the number fails to pass
    any of the tests, the program stops at that test,
    and that test's number is the errorCode. */
    
    public void check()
    {
        
        //1.  The first digit must be a 4.
        if (Integer.parseInt(number.substring(0,1))!=4)
        {
            validity=false;
            errorCode=1;
            return;
        }
        
        //2.  The fourth digit must be one greater than the fifth digit
        if (number.charAt(3) != number.charAt(4)+1)
        {     
            errorCode=2;
            validity=false;
            return;   
        }
        
        //3.  The product of the first, fifth, and ninth digits must be 24
        if (Integer.parseInt(number.substring(0,1))*
            Integer.parseInt(number.substring(4,5))*
            Integer.parseInt(number.substring(8,9)) != 24)
        {
                   
            errorCode=3;
            validity=false;
            return;
            
        }
        
        //4.  The sum of all digits must be evenly divisible by 4
        /* A for loop adds the numbers together, and an if statement
        checks to see if the sum is divisible by 4. */
        for (int i=0; i < number.length(); i++)
        {
            String currentNumber=number.substring(i,i+1);
            sum = sum + Integer.parseInt(currentNumber);
        }
        if (sum%4 != 0)
        {        
       
            errorCode=4;
            validity = false;
            return;
        }
        
        /* 5.  The sum of the first four digits must be one less 
        than the sum of the last four digits
        This one was tricky, but I had two for loops that got the sum 
        for the first 4 numbers and another that got 
        the sum of the last 4 numbers
        and an if statement that compares the two. */
        
        for (int i=0; i < 4; i++)
        {
            String currentNumber=number.substring(i,i+1);
            sum1 = sum1 + Integer.parseInt(currentNumber);
        }
        
        for (int i=8; i < 12; i++)
        {
            String currentNumber = number.substring(i,i+1);
            sum2=sum2+Integer.parseInt(currentNumber);
        }
        
        if (sum1+1 != sum2)
        {
       
            errorCode=5;
            validity=false;
            return;
            
        }
        /* 6. For this one, I got the substring for 
        the first two digits and the 
        7th and 8th digits and used Integer.parseInt() 
        to convert them to integers */
        if ((Integer.parseInt(number.substring(0,2))+
             Integer.parseInt(number.substring(6,8)))!=100)
        {
            
            errorCode=6;
            validity=false;
            return;
            
        }
        
                
    }
    
    // This method returns the errorCode
    public int getErrorCode()
     {          
         return errorCode;      
     } 
        
    // This method returns the validity    
    public boolean isValid()
    {        
        return validity;
    }
        
        
        
        
        
}