/*****************************************
 * This class models a Human Nim player
 * in a game of Nim
 * 
 * @author Hyun
 * @uni jh3888
 
 ****************************************/ 
import java.util.Scanner;

public class Human{
   
    private int choice;
    private Scanner input;
    
    
    public Human()
    {
        input=new Scanner(System.in);
        choice = -1;
        
    }
    
    /*The Human class is pretty simple;
    Just need to get input from human player on how many marbles
    they wish to take.
    
    The move() method is where this happens.
    the user-inputted value is set as choice */    
    public void move()
    {
        System.out.println("How many marbles would you like to take?");
        choice=input.nextInt();        
        
        
        
    }
    
    // Returns the choice that the player made    
    public int getChoice()
    {
        return choice;
    }
    
    
}
