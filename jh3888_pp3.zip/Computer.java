/*****************************************
 * this class models a Computer player
 * in a game of Nim
 * 
 * @author Hyun
 * @uni jh3888
 
 ****************************************/ 

public class Computer
{
    private int mode; //smart or stupid
    private int choice;
    
    public Computer(int m)
    {
        mode = m;
        //choice = -1;
    }
    /* move() is different for the Computer player is different from the Human's
    Basically, 2 scenarios must be accounted for: smart mode and stupid mode */
    public void move(int marblesLeft)
    {
        /* This is smart mode: pick enough marbles to make the pile
        (2^n)-1 for some n, unless the size of the pile is already 
        (2^n)-1, in which it makes some other legal move. */
        
        if ((mode==1)&&((marblesLeft!=3)&&(marblesLeft!=7)&&(marblesLeft!=15)&&
                        (marblesLeft!=31)&&(marblesLeft!=63)))
        {
            
            if ((marblesLeft>3) && (marblesLeft<7))
            {
                choice = (marblesLeft-3);
            }
            
            if ((marblesLeft>7) && (marblesLeft<15))
            {
                choice = (marblesLeft-7);
            }

            if ((marblesLeft>15) && (marblesLeft<31))
            {
                choice = (marblesLeft-15);
            }

            if ((marblesLeft>31) && (marblesLeft<63))
            {
                choice = (marblesLeft-31);
            }

            if ((marblesLeft>63) && (marblesLeft<=100))
            {
                choice = (marblesLeft-63);
            }
            if ((marblesLeft<=3)&&(marblesLeft>0))
            {
                choice = 1;
            }

                
        }
        /* considers the case in which either the computer is stupid
        or it can't make a "smart" move, in which case it makes a random
        legal move. */
        
        else
        {
            choice= (int)(Math.random()*((marblesLeft/2)))+1;
        }
        
    }
    
    // returns the Computer's choice
    public int getChoice()
    {
        return choice;
    }
    
    
}
