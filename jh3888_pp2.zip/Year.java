/*
*
* @author Ji Ho Hyun 
* @date 2/19/2018
*
* This class represents a calendar year.
*
* It contains a method that determines if
* the year is a leap year.
*
*/


public class Year{
    
    // declare your instance variables here
    int year;


    // write your constructor here

    public Year(int y)
    {
        year = y;
    }

    // using an if statement with some booleans,
    // isLeapYear() determines whether or not the inputted
    // year is a leap year.
    // The logic: if a year is divisible by 4 AND not divisible by 100,
    // or if it is divisible by 400, it is a leap year. 
    // Otherwise, it is not.
   
    public boolean isLeapYear()
    {
        if (year%4==0&&(!(year%100==0))||(year%400==0))
        {
            return true;
        }
        else 
        {
            return false;
        } 
        
    }

}    

