﻿README.txt
Name: Ji Ho Hyun
UNI: jh3888
Assignment: Programming Project 2


===============================================================================
<Problem 1 (Year.java)>
===============================================================================


I approached this problem using my knowledge of booleans. I wanted to make the code 
as simple as possible and I knew there was a single-if-statement restriction, so 
I set up isLeapYear() using a single if statement and an "or" qualifier.
This qualifier checks whether the year is divisible by 4 AND not divisible by 100,
or simply divisible by 400. In this manner I covered all possible leap years. I 
didn't use any methods other than the ones we have covered in class.




===============================================================================
<Problem 2 (Drunkard.java)>
===============================================================================


My approach to this problem was to look at different problems and examples and to 
derive a solution, like the Math.random class from the Coin example. 
In this case, I used an additional method called stumble() which determined the 
direction that the drunkard should travel in. In stumble, I used Math.random
multiplied by 4 to obtain 4 integers (0, 1, 2, and 3) to represent the 4 directions that the
drunkard can travel in. Then, step() moves the drunkard in that direction. Finally, fastForward()
runs n times, where n is the number of steps, utilizing the two methods established prior.
I did not use any methods outside what we have discussed in class. The only thing I used outside
the template was the stumble method that I created.