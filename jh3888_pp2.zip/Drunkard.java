/*
*
* @author Ji Ho Hyun
* @uni: jh3888
* @date 2/19/2018
*
* This class represents a drunkard.
*
* It contains methods that determines the direction, 
* moves the drunkard in that location,
* prints the location, 
* and calculates the distance 
* traveled by our friend.
*
*/

public class Drunkard
{
    
    // declaring instance variables here
    int year;
    int avenue;
    int street;
    int direction;
    int x;
    int y;
    int i;
    
    // writing constructor here:
    
    /* x and y represent the grid that the drunkard
       travels along; avenue and street are the initial
       location of the drunkard. */

    public Drunkard(int avenue, int street)
    {
        int x = avenue;
        int y = street;
    }
    
    /* stumble() determines a random direction for the drunkard
       to move in using Math.random()*4 which outputs 
       either 0, 1, 2, or 3 */
    
    public void stumble()
    {
        direction=(int) (Math.random()*4);
    }
    
    /* step() moves the drunkard in the direction determined in
       stumble() (x for avenue, y for street) */
    
    public void step()
    {
        if (direction==0)
        {
            x=x+1;
        }
        if (direction==1)
        {
            x=x-1;
        }
        if (direction==2)
        {
            y=y+1;
        }
        if (direction==3)
        {
            y=y-1;
        }
    }
    
    /* fastForward() is a method that runs the stumble()/step()
       sequence as many times as is inputted by the int "steps"
       moving one by one */
    
    public void fastForward(int steps)
    {
        for (int i=1; i<=steps; i++)
        {
            stumble();
            step();
           
        }
    }
    
    // returns the value of x and y
    public String getLocation()
    
    {
        return "The drunkard's location is now: ("+x+", "+y+")";
    }
    
    // calculating the distance traveled by the drunkard
    
    public int howFar()
    {
        return (Math.abs(avenue-x)+Math.abs(street-y));
    }
}
    
    