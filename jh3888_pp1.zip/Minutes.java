/**
 * This program converts a number of hours, days, weeks and years into minutes.
 * 
 * @author: <Ji Ho Hyun>
 * @uni: <jh3888>
 * @date: <2/1/18>
 */

import java.util.Scanner;

public class Minutes{
    
    public static void main(String[] args){
        
        //Creating a Scanner that reads various inputs
        //of years, weeks, days and hours:
        
        Scanner in = new Scanner(System.in);
        
        //Establishing constant values for the number of minutes
        //per year, week, day and hour:
        
        final int MINUTES_PER_HOUR = 60;
        final int MINUTES_PER_DAY = 1440;
        //(60 min/hr*24 hrs/day)
        final int MINUTES_PER_WEEK = 10080;
        //(60 min/hr*24 hrs/day*7 days/week)
        final int MINUTES_PER_YEAR = 525600;
        //(60 min/hr*24 hrs/day*7 days/week*365 days/year)
        
        //Prompt the user to enter a value:
        
        System.out.print("Enter a number of years, please: ");
        int numberYears = in.nextInt();
        
        System.out.print("Enter a number of weeks, please: ");
        int numberWeeks = in.nextInt();
        
        System.out.print("Enter a number of days, please: ");
        int numberDays = in.nextInt();
        
        System.out.print("Enter a number of hours, please: ");
        int numberHours = in.nextInt();
        
        
        //Perform calculations based on the input:
        //(the amount of minutes in a particular unit of time
        //multiplied by the number of units)
        
        //The total number of minutes is all the different calculations
        //added up
        
        int timeYears = MINUTES_PER_YEAR * numberYears;
        int timeWeeks = MINUTES_PER_WEEK * numberWeeks;
        int timeDays = MINUTES_PER_DAY * numberDays;
        int timeHours = MINUTES_PER_HOUR * numberHours;
        int totalMinutes = timeHours + timeDays + timeWeeks + timeYears;
        
        //Print the number of minutes
        System.out.println("Your total number of minutes is "+totalMinutes+"!");
            
    }
}