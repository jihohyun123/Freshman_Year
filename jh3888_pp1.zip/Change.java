/**
 * This program determines how to provide change given the amount received
 * and the amount due.
 * 
 * @author: <Ji Ho Hyun>
 * @uni: <jh3888>
 * @date: <2/2/18>
 */

import java.util.Scanner;

public class Change
{  
    public static void main(String[] args)
    {
        //Creating a new Scanner that reads what is inputted
        
        Scanner in = new Scanner(System.in);
        
        //Establishing the value of dollars, quarters, dimes, and nickels
        //in terms of pennies:
        
        final int PENNIES_PER_DOLLAR = 100;
        final int PENNIES_PER_QUARTER = 25;
        final int PENNIES_PER_DIME = 10;
        final int PENNIES_PER_NICKEL = 5;
        final int PENNIES_PER_PENNY = 1;
        
        //Getting the value of the amount due:
        
        System.out.print("Enter amount due (in pennies): ");
        int amountDue = in.nextInt();
        
        //Getting the amount received from customer:
         
        System.out.print("Enter the amount "
                         +"received from the customer (in pennies): ");
        int amountReceived = in.nextInt ();
        
        //Computing the change that is due:
        
        int changeDue = amountReceived - amountDue;
        
        //The number of dollars due is the changeDue divided by
        //the number of pennies per dollar
        int dollarsDue = changeDue / PENNIES_PER_DOLLAR;
        
        //Then take the remainder and divide that by the 
        //number of pennies per quarter to get the 
        //number of quarters due...etc., etc.
        
        int changeRemaining = changeDue % PENNIES_PER_DOLLAR;
        
        int quartersDue = changeRemaining / PENNIES_PER_QUARTER;
        
        changeRemaining = changeRemaining % PENNIES_PER_QUARTER;
        
        int dimesDue = changeRemaining / PENNIES_PER_DIME;
        
        changeRemaining = changeRemaining % PENNIES_PER_DIME;
        
        int nickelsDue = changeRemaining / PENNIES_PER_NICKEL;
        
        changeRemaining = changeRemaining % PENNIES_PER_NICKEL;
        
        int penniesDue = changeRemaining;
        
        //Account for scenario where user doesn't input enough money;
        //Print the change due
        
        if (changeDue < 0)
        {
            System.out.print("You do not have enough money!"+"\n");
        }
        else
        {
            System.out.print("Your change is: "+"\n");
            System.out.printf("Dollars: %1d", dollarsDue);
            System.out.println();
            System.out.printf("Quarters: %1d", quartersDue);
            System.out.println();
            System.out.printf("Dimes: %1d", dimesDue);
            System.out.println();
            System.out.printf("Nickels: %1d", nickelsDue);
            System.out.println();
            System.out.printf("Pennies: %1d", penniesDue);
            System.out.println();
         }
        
    }

}	