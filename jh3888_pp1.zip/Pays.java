/**
 * This program determines the correct article to use for different
 * countries.
 * 
 * @author: <Ji Ho Hyun>
 * @uni: <jh3888>
 * @date: <2/2/18>
 */

import java.util.Scanner;

public class Pays{

    public static void main(String[] args)
    {
        //Creating a new Scanner that can read input
        Scanner in = new Scanner(System.in);
        //Scans for the country's name
          
        //Prompt the reader for the name of the country
        System.out.print("Enter country name, please (in French): ");
        String countryName = in.nextLine();
        //Storing the name of the country in a variable
        
        //Initializing string article
        String article="le";
         
        //"If" statement now checks for the plural countries
       
        if (countryName.equals("Etats-Unis"))
        {
            article = "les";            
        }
        else if (countryName.equals("Pays-Bas"))
        {
            article = "les";            
        }
        
        //"Else if" statement that checks the first letter of the countryName for vowels:
            
        else if (countryName.substring(0,1).equals("A"))
        {
            article = "l'";            
        }
        else if (countryName.substring(0,1).equals("E"))
        {
            article = "l'";           
        }
        else if (countryName.substring(0,1).equals("I"))
        {
            article = "l'";            
        }
        else if (countryName.substring(0,1).equals("O"))
        {
            article = "l'";            
        }
        else if (countryName.substring(0,1).equals("U"))
        {
            article = "l'";            
        }
        
        //Continuing the "else if" statements, now checking 
        //for the unique countries that end in "e" yet require "le"
        
        else if (countryName.equals("Belize"))
        {
            article = "le";            
        }
        else if (countryName.equals("Cambodge"))
        {
            article = "le";            
        }
        else if (countryName.equals("Mexique"))
        {
            article = "le";            
        }
        else if (countryName.equals("Mozambique"))
        {
            article = "le";            
        }
        else if (countryName.equals("Zaire"))
        {
            article = "le";            
        }
        else if (countryName.equals("Zimbabwe"))
        {
            article = "le";
        }    
        
        //"Else if" statement that checks if the 
        //last letter is "e", not including exceptions:
        else if (countryName.substring(countryName.length() - 1).equals("e"))
        {
           article = "la";                
        }
        
        //This covers all the possible articles, as the only option remaining
        //is "le" if none of the above conditions have been fulfilled.
        
        //Printing out a statement with the right article:
        //"l'" does not have a space after it, 
        //while "les", "la", and "le" all do...
        
        //Had to create two separate Print commands: 
        //one with a space(" "), one without(for the "l'" countries)
        
        if (article.equals("l'"))
        {
            System.out.println("Inputted country with "
                           +"correct article: "+ article + countryName);
        }
        else
        {
            System.out.println("Inputted country with "
                           +"correct article: "+ article + " " + countryName);
        }    
            
    }

}